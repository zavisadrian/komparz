<section id="modal-template">
	<div id="myModal" class="map-modal" style="display: none">
	<!-- Modal content -->
		<div class="modal-content text-center">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d170410.75606687134!2d16.97583507105868!3d48.13592437329355!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x476c89360aca6197%3A0x631f9b82fd884368!2sBratislava!5e0!3m2!1ssk!2ssk!4v1568010970627!5m2!1ssk!2ssk" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
			<a class="close-me"><i class="fa fa-times" aria-hidden="true"></i></a>
		</div>
	</div>
</section>