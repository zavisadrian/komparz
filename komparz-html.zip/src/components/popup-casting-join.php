<section id="modal-template">
	<div id="myModal" class="modal" style="display: none">
	<!-- Modal content -->
		<div class="modal-content text-center">
			<div class="row text-center">
				<div class="col-12">
					<h2 class="mb-4">Bezplatná online prihláška na CASTING</h2>
					<div class="row">
						<div class="col-md-6">
							<input type="text" placeholder="Meno a Priezvisko">
							<input type="text" placeholder="Emailová adresa">
							<input type="text" placeholder="Telefón">
							<input type="text" placeholder="Mesto Bydliska">
							<input type="text" placeholder="Rok narodenia">
						</div>
						<div class="col-md-6 pb-2">
							<textarea name="" id="" rows="10" class="h-100" placeholder="Zaujímavé informácie o Vás"></textarea>
						</div>
					</div>
					<a class="btn btn-dark mt-md-5 mt-3 w-50 send">Odoslať</a>
				</div>
			</div>
			<a class="close-me"><i class="fa fa-times" aria-hidden="true"></i></a>
		</div>
	</div>
</section>