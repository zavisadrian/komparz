<section id="modal-template">
	<div id="myModal" class="log-in" style="display: none">
	<!-- Modal content -->
		<div class="modal-content text-center">
			<div class="row text-center">
				<div class="col-12">
					<h2 class="mb-4">Kontatujte našu agentúru</h2>
					<div class="row">
						<div class="col-md-12">
							<input type="text" placeholder="E-mail">
							<input type="text" placeholder="Heslo">
							<div class="custom-control square-checkbox py-md-3 pt-3">
								<input type="checkbox" class="custom-control-input" id="1" name="1">
								<label class="custom-control-label " for="1">Zapamätať</label>
							</div>
						</div>
					</div>
					<a class="btn btn-dark mt-md-2 mt-3 w-50 send">Prihlásiť</a>
				</div>
			</div>
			<a class="close-me"><i class="fa fa-times" aria-hidden="true"></i></a>
		</div>
	</div>
</section>