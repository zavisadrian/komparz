<div class="card event text-center">
	<i class="fa fa-user mt-3" aria-hidden="true"></i>
	<h2 class="mt-3">CASTING</h2>
	<h3>17.11.2020 Bratislava</h3>
	<p class="mb-3 mt-4">casting@komparz.tv | www.KOPARZ.tv</p>
	<div class="card-body text-left">
		<p class="pt-3"><strong>Schwarzkopf Professional - BRATISLAVA</strong></p>
		<p class="light pb-4">17.11.2018 (sobota) v čase o 10:00 hodine <br>SKP štúdio Henkel SR, Záhradnícka 91, Bratislava</p>
	</div>
</div>